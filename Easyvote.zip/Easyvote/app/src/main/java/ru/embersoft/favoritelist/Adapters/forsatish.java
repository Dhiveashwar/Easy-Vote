package ru.embersoft.favoritelist.Adapters;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.easyvote.R;


public class forsatish extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forsatish);
    }

    @Override
    public void onBackPressed () {

    }
}