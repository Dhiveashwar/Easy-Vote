package ru.embersoft.favoritelist.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.easyvote.R;

import java.util.ArrayList;

import ru.embersoft.favoritelist.Adapters.CoffeeAdapter;
import ru.embersoft.favoritelist.Helpers.CoffeeItem;


public class HomeFragment extends Fragment {

    private ArrayList<CoffeeItem> coffeeItems = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(new CoffeeAdapter(coffeeItems, getActivity()));
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));


        coffeeItems.add(new CoffeeItem(R.drawable.bjplogo, "Narendra Modi","0","0","Gujarat","Bharatha Janatha Party"));
        coffeeItems.add(new CoffeeItem(R.drawable.trinamoolcongresslogo, "Mamata Banerjee","1","0","West Bengal","Trinamool Congress"));
        coffeeItems.add(new CoffeeItem(R.drawable.indiannationalcongress, "Sonia Gandhi","2","0","Chattisgarh","Indian National Congress"));
        coffeeItems.add(new CoffeeItem(R.drawable.samajwadiparty, "Kamal Morarka","3","0","Uttar Pradesh","Samajwadi Party"));
        coffeeItems.add(new CoffeeItem(R.drawable.aam_admi_part, "Arvind Kejriwal","4","0","Delhi","Aam Aadmi Party"));



        return root;
    }
}