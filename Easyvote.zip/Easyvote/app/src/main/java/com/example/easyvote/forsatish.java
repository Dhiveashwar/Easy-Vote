package com.example.easyvote;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;



public class forsatish extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forsatish);
    }

    @Override
    public void onBackPressed () {

    }
}