package com.example.easyvote;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;

import android.content.Intent;

public class submitted extends AppCompatActivity {
    Timer timer;
    int counter=0;
    TextView showValue,sv;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submitted);

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(submitted.this,com.example.easyvote.dash2.class);
                startActivity(intent);
                finish();
            }
        }, 1800);

    }

}
