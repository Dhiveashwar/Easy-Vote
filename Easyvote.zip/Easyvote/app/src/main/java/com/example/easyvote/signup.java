package com.example.easyvote;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;
import android.os.Bundle;
import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.InputStream;
import java.util.Random;

public class signup extends AppCompatActivity {
    EditText fullname, mobileno, email, aadharno, voterid, password, emai, pass;
    Uri filepath;
    ImageView img;
    Button browse,signup;
    Bitmap bitmap;
    AwesomeValidation awesomeValidation;
    ProgressBar progressbar;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        mAuth = FirebaseAuth.getInstance();
        img=(ImageView)findViewById(R.id.img);
        signup=(Button)findViewById(R.id.upload);
        browse=(Button)findViewById(R.id.browse);

        fullname=(EditText)findViewById(R.id.fullname);
        mobileno=(EditText)findViewById(R.id.mobileno);
        email=(EditText)findViewById(R.id.email);
        aadharno=(EditText)findViewById(R.id.aadharno);
        voterid=(EditText)findViewById(R.id.voterid);
        password=(EditText)findViewById(R.id.password);

        emai = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        signup = findViewById(R.id.upload);
        progressbar = findViewById(R.id.progressbar);









        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        awesomeValidation.addValidation(this,R.id.img,
                RegexTemplate.NOT_EMPTY,R.string.invalid_photo);

        awesomeValidation.addValidation(this,R.id.fullname,
                RegexTemplate.NOT_EMPTY,R.string.invalid_name);

        awesomeValidation.addValidation(this,R.id.mobileno,
                "[0-9]{10}",R.string.invalid_mobileno);

        awesomeValidation.addValidation(this,R.id.email,
                Patterns.EMAIL_ADDRESS,R.string.invalid_email);

        awesomeValidation.addValidation(this,R.id.aadharno,
                "[0-9]{12}",R.string.invalid_aadharno);

        awesomeValidation.addValidation(this,R.id.voterid,
                "[A-Z0-9]{10}",R.string.invalid_voterid);

        awesomeValidation.addValidation(this,R.id.password,
                ".{6,24}",R.string.invalid_password);

        browse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dexter.withActivity(signup.this)
                        .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse response)
                            {
                                Intent intent=new Intent(Intent.ACTION_PICK);
                                intent.setType("image/*");
                                startActivityForResult(Intent.createChooser(intent,"Select Image File"),1);
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse response) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        }).check();
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (awesomeValidation.validate()){
                    Toast.makeText(getApplicationContext(),
                            "Form Validated Succesfully...",Toast.LENGTH_SHORT).show();
                    uploadtofirebase();
                    registerNewUser();
                } else if (awesomeValidation.validate()){
                    Toast.makeText(getApplicationContext(),
                            "Validation Failed!",Toast.LENGTH_SHORT).show();

                }
            }

        });

    }





    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        if(requestCode==1  && resultCode==RESULT_OK)
        {
            filepath=data.getData();
            try{
                InputStream inputStream=getContentResolver().openInputStream(filepath);
                bitmap= BitmapFactory.decodeStream(inputStream);
                img.setImageBitmap(bitmap);
            }catch (Exception ex)
            {

            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }







    private void uploadtofirebase()
    {
        final ProgressDialog dialog=new ProgressDialog(this);
        dialog.setTitle("File Uploader");
        dialog.show();

        fullname=(EditText)findViewById(R.id.fullname);
        mobileno=(EditText)findViewById(R.id.mobileno);
        email=(EditText)findViewById(R.id.email);
        aadharno=(EditText)findViewById(R.id.aadharno);
        voterid=(EditText)findViewById(R.id.voterid);
        password=(EditText)findViewById(R.id.password);


        FirebaseStorage storage=FirebaseStorage.getInstance();
        final StorageReference uploader=storage.getReference("Image1"+new Random().nextInt(50));

        uploader.putFile(filepath)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
                    {
                        uploader.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri){

                                dialog.dismiss();
                                FirebaseDatabase db=FirebaseDatabase.getInstance();
                                DatabaseReference root=db.getReference("Users");

                                dataholder obj=new dataholder(fullname.getText().toString(),mobileno.getText().toString(),email.getText().toString(),aadharno.getText().toString(),voterid.getText().toString(),password.getText().toString(),uri.toString());
                                root.child(fullname.getText().toString()).setValue(obj);

                                fullname.setText("");
                                mobileno.setText("");
                                email.setText("");
                                aadharno.setText("");
                                voterid.setText("");
                                password.setText("");
                                img.setImageResource(R.drawable.ic_launcher_background);
                                Toast.makeText(getApplicationContext(),"Uploaded",Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot)
                    {
                        float percent=(100*taskSnapshot.getBytesTransferred())/taskSnapshot.getTotalByteCount();
                        dialog.setMessage("Uploaded :"+(int)percent+" %");
                    }
                });
}

    private void registerNewUser()
    {

        // show the visibility of progress bar to show loading
        progressbar.setVisibility(View.VISIBLE);

        // Take the value of two edit texts in Strings
        String email, password;
        email = emai.getText().toString();
        password = pass.getText().toString();

        // Validations for input email and password

        Task<AuthResult> authResultTask = mAuth
                .createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                            Intent intent
                                    = new Intent(signup.this,
                                    evoteloginpage.class);
                            startActivity(intent);
                        }

                });}

 public void OpenSigninPage(View view) {
        startActivity(new Intent(this,evoteloginpage.class));}}



