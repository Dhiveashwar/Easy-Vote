package com.example.easyvote;

public class dataholder
{
    String fullname, mobileno, email, aadharno, voterid, password, pimage;

    public dataholder(String fullname, String mobileno, String email, String aadharno, String voterid, String password, String pimage) {
        this.fullname = fullname;
        this.mobileno = mobileno;
        this.email = email;
        this.aadharno = aadharno;
        this.voterid = voterid;
        this.password = password;
        this.pimage = pimage;
    }

    public dataholder(String fullname, String mobileno, String aadharno, String voterno) {
    }

    public String getName() {
        return fullname;
    }

    public void setName(String name) {
        this.fullname = name;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAadharno() {
        return aadharno;
    }

    public void setAadharno(String aadharno) {
        this.aadharno = aadharno;
    }

    public String getVoterid() {
        return voterid;
    }

    public void setVoterid(String voterid) {
        this.voterid = voterid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }
}