package com.example.easyvote;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

public class dash2 extends AppCompatActivity {

    SessionManager session;
    Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash2);
        session = new SessionManager(getApplicationContext());

        TextView lblName = (TextView) findViewById(R.id.editTextTextPersonName);
        TextView lblEmail = (TextView) findViewById(R.id.editTextTextEmailAddress2);
        btnLogout = (Button) findViewById(R.id.logout3);
        session.checkLogin();

        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
        String name = user.get(SessionManager.KEY_NAME);

        // email
        String email = user.get(SessionManager.KEY_EMAIL);

        // displaying user data
        lblName.setText(Html.fromHtml("<b>Hello " + name + "</b>"));

        btnLogout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // Clear the session data
                // This will clear all session data and
                // redirect user to LoginActivity
                session.logoutUser();
            }
        });}

    @Override
    public void onBackPressed () {

    }

    public void candidatepage(View view) {
        startActivity(new Intent(this,candidate.class));}

    public void aboutuspage(View view) {
        startActivity(new Intent(this,aboutus.class));}

    public void openvote(View view) {
        startActivity(new Intent(this,dash2.class));
        Toast.makeText(dash2.this, "Already Voted", Toast.LENGTH_SHORT).show();
        }

    public void openresult(View view) {
        startActivity(new Intent(this,Result.class));}

    public void openprofile(View view) {
        startActivity(new Intent(this,profile.class));}
}