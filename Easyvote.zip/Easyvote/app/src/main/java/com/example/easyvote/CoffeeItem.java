package com.example.easyvote;

public class CoffeeItem {

    private int imageResourse;
    private String title;
    private String key_id;
    private String favStatus;
    private String subtitle;
    private String subtitle2;

    public CoffeeItem() {
    }

    public CoffeeItem(int imageResourse, String title, String key_id, String favStatus,String subtitle,String subtitle2) {
        this.imageResourse = imageResourse;
        this.title = title;
        this.key_id = key_id;
        this.favStatus = favStatus;
        this.subtitle = subtitle;
        this.subtitle2 = subtitle2;
    }

    public int getImageResourse() {
        return imageResourse;
    }

    public void setImageResourse(int imageResourse) {
        this.imageResourse = imageResourse;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getsubtitle() {
        return subtitle;
    }

    public void setsubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getsubtitle2() {
        return subtitle2;
    }

    public void setsubtitle2(String subtitle2) {
        this.subtitle2 = subtitle2;
    }

    public String getKey_id() {
        return key_id;
    }

    public void setKey_id(String key_id) {
        this.key_id = key_id;
    }

    public String getFavStatus() {
        return favStatus;
    }

    public void setFavStatus(String favStatus) {
        this.favStatus = favStatus;
    }

}
