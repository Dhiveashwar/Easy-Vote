package com.example.easyvote;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class candidate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_candidate);
    }
}