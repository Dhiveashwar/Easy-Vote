package com.example.easyvote;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.load.model.Model;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;


public class profile extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ImageView avatartv;
    TextView nam, edtPhone,email,edtAadhar,edtVoter;
    RecyclerView postrecycle;
    Button fab;
    SessionManager session;
    String uid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        session = new SessionManager(getApplicationContext());
        firebaseAuth = FirebaseAuth.getInstance();

        // getting current user data
     firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
     uid = firebaseUser.getUid();
        databaseReference = firebaseDatabase.getInstance().getReference("Users");

        // Initialising the text view and imageview
        avatartv = findViewById(R.id.imageView);
        nam = findViewById(R.id.editTextTextPersonName);
        email = findViewById(R.id.editTextTextEmailAddress2);
        edtPhone = findViewById(R.id.editTextPhone7);
        edtAadhar = findViewById(R.id.editTextNumber);
        edtVoter = findViewById(R.id.editTextNumber2);



        session.checkLogin();

        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
        String name = user.get(SessionManager.KEY_NAME);

        // email
        String emaill = user.get(SessionManager.KEY_EMAIL);

        // displaying user data
        nam.setText(Html.fromHtml( name + "</b>"));
        email.setText(Html.fromHtml( emaill + "</b>"));


        getuserdata();
    }


    private void getuserdata()
    {
databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                // Retrieving Data from firebase
                String name = "" + dataSnapshot.child("Divesh").child("name").getValue(String.class);
                String mobileno = "" + dataSnapshot.child("Divesh").child("mobileno").getValue(String.class);
                String emaill = "" + dataSnapshot.child("Divesh").child("email").getValue(String.class);
                String aadharno = "" + dataSnapshot.child("Divesh").child("aadharno").getValue(String.class);
                String voterid = "" + dataSnapshot.child("Divesh").child("voterid").getValue(String.class);

                String image = "" + dataSnapshot.child(uid).getValue(String.class);
                // setting data to our text view


                nam.setText(name);
                email.setText(emaill);
                edtPhone.setText(mobileno);
                edtAadhar.setText(aadharno);
                edtVoter.setText(voterid);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        // On click we will open EditProfileActiity


    }

}


